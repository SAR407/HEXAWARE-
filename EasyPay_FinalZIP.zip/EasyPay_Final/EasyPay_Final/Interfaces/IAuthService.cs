﻿using EasyPay_Final.Models;

namespace EasyPay_Final.Interfaces
{
    public interface IAuthService
    {
        Task<string> LoginAsync(string username, string password); // returns JWT
        Task LogoutAsync(string token);
        Task<User> RegisterAsync(User user, string password);
    }

}
