﻿using EasyPay_Final.Models;

namespace EasyPay_Final.Interfaces
{
    public interface IAuditService
    {
        Task LogActionAsync(string performedBy, string action, string details);
        Task<IEnumerable<AuditLog>> GetAuditLogsAsync();
    }

}
