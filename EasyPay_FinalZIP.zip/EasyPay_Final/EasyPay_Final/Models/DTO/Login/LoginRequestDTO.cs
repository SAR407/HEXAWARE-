﻿namespace EasyPay_Final.Models.DTO.Login.cs
{
    public class LoginRequestDTO
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
    }
}
