﻿namespace EasyPay_Final.Models.DTO.Login.cs
{
    public class LoginResponseDTO
    {
        public string? Token { get; set; }
        public string? Role { get; set; }
        public string? Username { get; set; }
    }
}
